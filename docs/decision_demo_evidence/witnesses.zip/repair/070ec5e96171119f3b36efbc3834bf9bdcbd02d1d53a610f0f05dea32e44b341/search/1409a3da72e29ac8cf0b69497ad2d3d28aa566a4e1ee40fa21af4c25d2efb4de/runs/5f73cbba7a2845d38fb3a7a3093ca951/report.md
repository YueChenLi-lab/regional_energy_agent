# 区域综合能源低碳规划评估报告

项目：合成反事实修复验收 · 24小时 · 非真实工程

运行 ID：`5f73cbba7a2845d38fb3a7a3093ca951`；输入版本：2；状态：完成。

**合成演示数据**：负荷、资源、价格、排放因子和设备费用为演示假设，不代表当地现行参数。

## 任务条件

24 个区间，时间步长 1 h，评估时长 24 h。区间开始时间：2025-01-06T00:00:00+08:00 至 2025-01-06T23:00:00+08:00；最后区间结束时间为最后开始时间加一个时间步。仅报告该时段结果。

| 条件 | 数值 | 单位 |
| --- | --- | --- |
| 初始投资预算 | 60,000.0000 | 元 |
| 评估期排放上限 | 239.7412 | kgCO2e |
| 电网购电功率上限 | 12.0000 | kW |
| 光伏场地上限 | 180.0000 | kW |

项目条件来源：`revision-v2`。

求解设置：每个候选时限 3 秒；相对最优性间隙容差 1e-06。

规划模式：candidates；时间分辨率标识：period。

## 候选配置与结果

| 方案 | 光伏 kW | 电池 kW / kWh | 热泵 kW_th | 锅炉 kW_th | 投资 元 | 运行费 元 | 排放 kgCO2e | 求解状态 | 约束通过 | 容量来源 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A 电网＋锅炉 | 0.0000 | 0 / 0 | 0.0000 | 20.0000 | 15,750.0000 | 341.1667 | 239.7333 | 已证明最优（该候选运行） | 是 | demo-candidates |
| C 电网＋热泵 | 0.0000 | 0 / 0 | 20.0000 | 0.0000 | 51,400.0000 | — | — | 运行无解 | 否 | demo-candidates |
| D 光伏＋储能＋热泵 | 50.0000 | 20 / 150 | 20.0000 | 0.0000 | 401,000.0000 | — | — | 预检查不通过 | 否 | demo-candidates |

| 方案 | 购电 kWh | 燃气 kWh_LHV | 弃光 kWh | 常规用电 kWh | 供热 kWh_th | 供能满足 | 求解秒数 | 相对最优性间隙 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | 240.0000 | 533.3333 | 0.0000 | 240.0000 | 480.0000 | 是 | 0.0025 | 0.0000 |
| C | — | — | — | — | — | 未验证（无运行解） | 6.317e-05 | — |
| D | — | — | — | — | — | 未验证（无运行解） | 5.965e-06 | — |

## 比较与推荐

在本次评估的候选方案中，推荐 **A**。在本次评估的候选方案中，A 通过全部约束校验，按评估期运行费升序排名第一。初始投资与评估期排放单独展示；此结果不代表全部可能容量配置的全局最优。

先筛选预算、供能与排放等约束，再按本评估期运行费排序；投资与排放完整列出以展示取舍。若某候选仅取得可行解，则排序基于当前可行解，不能据此证明该候选运行最优。

## 不可行、未完成求解与独立检查

### A：已证明最优（该候选运行）

HiGHS 在所设容差内求得最优运行解

| 检查 | 通过 | 最大违反量 | 容差 | 说明 |
| --- | --- | --- | --- | --- |
| solver_has_solution | 是 | 0.0000 | 0.0000 | 求解状态：optimal |
| candidate_identity | 是 | 0.0000 | 0.0000 |  |
| result_dimensions | 是 | 0.0000 | 0.0000 | 逐时点=N，SOC=N+1，充放电模式=N |
| timestamps | 是 | 0.0000 | 0.0000 |  |
| objective_available | 是 | 0.0000 | 0.0000 |  |
| electric_balance | 是 | 0.0000 | 1e-05 |  |
| heat_balance | 是 | 0.0000 | 1e-05 |  |
| heat_pump_cop | 是 | 0.0000 | 1e-05 |  |
| boiler_efficiency | 是 | 0.0000 | 1e-05 |  |
| pv_allocation | 是 | 0.0000 | 1e-05 |  |
| nonnegative_flows | 是 | 0.0000 | 1e-05 |  |
| grid_limit | 是 | 0.0000 | 1e-05 |  |
| pv_availability | 是 | 0.0000 | 1e-05 |  |
| heat_pump_capacity | 是 | 0.0000 | 1e-05 |  |
| boiler_capacity | 是 | 0.0000 | 1e-05 |  |
| battery_charge_power | 是 | 0.0000 | 1e-05 |  |
| battery_discharge_power | 是 | 0.0000 | 1e-05 |  |
| soc_lower | 是 | 0.0000 | 1e-05 |  |
| soc_upper | 是 | 0.0000 | 1e-05 |  |
| soc_initial | 是 | 0.0000 | 1e-05 |  |
| soc_terminal | 是 | 0.0000 | 1e-05 | 期末必须恢复初始能量，不允许免费消耗初始储能 |
| soc_dynamics | 是 | 0.0000 | 1e-05 |  |
| binary_charge_mode | 是 | 0.0000 | 1e-05 |  |
| charge_mode_limit | 是 | 0.0000 | 1e-05 |  |
| discharge_mode_limit | 是 | 0.0000 | 1e-05 |  |
| no_simultaneous_charge_discharge | 是 | 0.0000 | 1e-05 |  |
| investment_budget | 是 | 0.0000 | 0.0001 |  |
| pv_site_limit | 是 | 0.0000 | 1e-05 |  |
| emission_limit | 是 | 0.0000 | 0.0001 | 按评估期统计 |
| objective_recalculation | 是 | 0.0000 | 0.0001 |  |

### C：运行无解

供电能力必要条件预检查失败

- 2025-01-06T00:00:00+08:00 常规负荷与最低热泵耗电之和超过电网、可用光伏和最大放电功率之和 4.250 kW；此上界尚未考虑电池能量限制

| 检查 | 通过 | 最大违反量 | 容差 | 说明 |
| --- | --- | --- | --- | --- |
| solver_has_solution | 否 | 1.0000 | 0.0000 | 求解状态：infeasible |
| candidate_identity | 是 | 0.0000 | 0.0000 |  |
| result_dimensions | 否 | 1.0000 | 0.0000 | 逐时点=N，SOC=N+1，充放电模式=N |

### D：预检查不通过

候选未通过规划约束预检查

- 初始投资 401000.00 元超过预算 60000.00 元

| 检查 | 通过 | 最大违反量 | 容差 | 说明 |
| --- | --- | --- | --- | --- |
| solver_has_solution | 否 | 1.0000 | 0.0000 | 求解状态：rejected |
| candidate_identity | 是 | 0.0000 | 0.0000 |  |
| result_dimensions | 否 | 1.0000 | 0.0000 | 逐时点=N，SOC=N+1，充放电模式=N |

## 设备与投资假设（新建项目）

| 参数 | 值 | 单位 |
| --- | --- | --- |
| 光伏设备单价 | 3,200.0000 | 元/kW |
| 电池能量单价 | 900.0000 | 元/kWh |
| 电池功率单价 | 450.0000 | 元/kW |
| 热泵设备单价 | 1,800.0000 | 元/kW_th |
| 锅炉设备单价 | 250.0000 | 元/kW_th |
| 安装费/设备费 | 0.1500 | 无量纲 |
| 电网接入费用 | 10,000.0000 | 元 |
| 固定热泵 COP | 3.2000 | kWh_th/kWh |
| 锅炉效率 | 0.9000 | kWh_th/kWh_LHV |
| 充电效率 / 放电效率 | 0.95 / 0.95 | 无量纲 |
| SOC 下限 / 上限 / 初值 | 0.1 / 0.9 / 0.5 | 额定能量比例 |

设备参数与费用来源：`demo-equipment`。

初始投资 = 设备购置费合计 × (1 + 安装费比例) + 电网接入费。电网接入费对所有候选采用相同口径。

## 数据与参数来源

| 项目 | 记录 |
| --- | --- |
| source_id | demo-series |
| 名称 | 合成演示数据：电热负荷与光伏 |
| 地区 | 虚构园区（未知真实地区） |
| 时间范围 | 2025-01-06T00:00:00+08:00 至 2025-01-07T00:00:00+08:00（末端不含） |
| 类别 | synthetic |
| 单位 | {"electric_load_kw": "kW", "heat_load_kw_th": "kW_th", "pv_per_kw": "kW/kW"} |
| 处理记录 | NumPy default_rng 固定随机种子 42；电热负荷：解析日周期加正态随机扰动后非负裁剪；光伏：正弦包络乘有界均匀随机系数，夜间显式置零；反事实验收合成负荷：常规电功率恒10kW，热功率恒20kW_th；原168小时随机日型未拼接或年化；光伏沿用固定种子逐时合成 |
| 使用条件 | 仅用于功能演示，非实测，不能直接用于工程决策 |
| 发布链接 | 未知 |
| 版本 | 未知 |
| 原始文件、SHA-256与获取时间 | [] |
| 父来源 | 无 / 未知 |

| 项目 | 记录 |
| --- | --- |
| source_id | demo-market |
| 名称 | 合成演示数据：价格与排放因子假设 |
| 地区 | 未知 |
| 时间范围 | 2025-01-06T00:00:00+08:00 至 2025-01-07T00:00:00+08:00（末端不含） |
| 类别 | synthetic |
| 单位 | {"electricity_price": "元/kWh", "gas_price": "元/kWh_LHV", "grid_emission_factor": "kgCO2e/kWh", "gas_emission_factor": "kgCO2e/kWh_LHV"} |
| 处理记录 | 预设峰谷电价、固定燃气价格和排放因子 |
| 使用条件 | 全部为演示假设，不代表当地现行价格或排放因子 |
| 发布链接 | 未知 |
| 版本 | 未知 |
| 原始文件、SHA-256与获取时间 | [] |
| 父来源 | 无 / 未知 |

| 项目 | 记录 |
| --- | --- |
| source_id | demo-equipment |
| 名称 | 合成演示数据：设备与新建成本假设 |
| 地区 | 未知 |
| 时间范围 | 未知 |
| 类别 | synthetic |
| 单位 | {"hp_cop": "kWh_th/kWh", "efficiency_and_soc": "1", "pv_cost_per_kw": "元/kW", "battery_cost_per_kwh": "元/kWh", "battery_power_cost_per_kw": "元/kW", "hp_cost_per_kw_th": "元/kW_th", "boiler_cost_per_kw_th": "元/kW_th", "installation_fraction": "1", "grid_connection_cost_yuan": "元"} |
| 处理记录 | 读取 demo_config.json |
| 使用条件 | 演示假设；统一新建投资；安装费为设备购置费的15%，接入费单列 |
| 发布链接 | 未知 |
| 版本 | 未知 |
| 原始文件、SHA-256与获取时间 | [] |
| 父来源 | 无 / 未知 |

| 项目 | 记录 |
| --- | --- |
| source_id | demo-conditions |
| 名称 | 合成演示数据：项目条件 |
| 地区 | 未知 |
| 时间范围 | 未知 |
| 类别 | synthetic |
| 单位 | {"budget_yuan": "元", "grid_limit_kw": "kW", "pv_limit_kw": "kW", "emission_limit_kg": "kgCO2e"} |
| 处理记录 | 读取 demo_config.json；研究假设：预算60000元，购电12kW，排放上限按hours*230/24 kgCO2e；只统计实际输入期 |
| 使用条件 | 预算、场地和接入功率均为演示假设 |
| 发布链接 | 未知 |
| 版本 | 未知 |
| 原始文件、SHA-256与获取时间 | [] |
| 父来源 | 无 / 未知 |

| 项目 | 记录 |
| --- | --- |
| source_id | demo-candidates |
| 名称 | 合成演示数据：有限候选容量 |
| 地区 | 未知 |
| 时间范围 | 未知 |
| 类别 | synthetic |
| 单位 | {"pv_kw": "kW", "battery_power_kw": "kW", "battery_energy_kwh": "kWh", "hp_kw_th": "kW_th", "boiler_kw_th": "kW_th"} |
| 处理记录 | 读取 demo_config.json 的四个明确容量组合；研究假设：三个固定候选A(锅炉20)、C(热泵20)、D(光伏50/储能20kW150kWh/热泵20)；容量不随约束放宽而改变 |
| 使用条件 | 不代表所有可能配置；辅助锅炉不构成故障备用保证 |
| 发布链接 | 未知 |
| 版本 | 未知 |
| 原始文件、SHA-256与获取时间 | [] |
| 父来源 | 无 / 未知 |

| 项目 | 记录 |
| --- | --- |
| source_id | revision-v2 |
| 名称 | 用户场景修改 v2 |
| 地区 | 未知 |
| 时间范围 | 2025-01-06T00:00:00+08:00 至 2025-01-07T00:00:00+08:00（末端不含） |
| 类别 | synthetic |
| 单位 | {"budget_yuan": "元", "emission_limit_kg": "kgCO2e", "grid_limit_kw": "kW", "pv_limit_kw": "kW", "demand_scale": "1", "electric_load_kw": "kW", "heat_load_kw_th": "kW_th", "discount_rate": "1", "horizon_years": "年", "lifetime_years": "年", "fixed_om_fraction": "1/年", "additional_fixed_om_yuan_per_year": "元/年"} |
| 处理记录 | 由输入v1派生；父运行 93ecbb892f3f40ec94ab01a8e8c83136；{"emission_limit_kg": 239.7412109375}；负荷缩放作用于全部已提供时间区间；无缺失填充；反事实探索；是否采用以单独的显式确认回执为准，未改写基准任务 |
| 使用条件 | 用户设定的场景；原始来源保留；合成演示属性保持 |
| 发布链接 | 未知 |
| 版本 | 未知 |
| 原始文件、SHA-256与获取时间 | [] |
| 父来源 | 无 / 未知 |

时序字段来源映射：

| 字段 | source_id | 单位 |
| --- | --- | --- |
| electric_load_kw | demo-series | kW |
| heat_load_kw_th | demo-series | kW_th |
| pv_per_kw | demo-series | kW/kW |
| electricity_price | demo-market | 元/kWh |
| gas_price | demo-market | 元/kWh_LHV |
| grid_emission_factor | demo-market | kgCO2e/kWh |
| gas_emission_factor | demo-market | kgCO2e/kWh_LHV |

## 模型假设、适用范围与尚未实现内容

- 区域内所有建筑合并为一个供能节点，仅建模常规用电和供热，要求每个时间区间足额供能。
- 光伏、电池、热泵和燃气锅炉按新建项目计投资；预算约束初始投资，运行费仅统计本评估期。
- 热泵采用固定 COP，锅炉采用固定效率；燃气统一按低位热值 kWh_LHV 计量。
- 电池以 N+1 个区间边界状态记录：SOC[t] 是区间 t 开始状态，SOC[t+1] 是结束状态；期末等于期初。
- 电池充放电使用二进制互斥约束；不允许售电，不采用隐含缺供或负荷削减。
- 排放为购电与燃气使用的运行阶段排放，不代表设备全生命周期排放或全生命周期零碳。
- 仅比较配置文件提供的有限候选；不构成连续容量空间的全局规划最优证明。
- 尚未实现供冷、冷热管网、空间选址、设备故障备用、售电、绿证、碳抵消、全生命周期隐含排放。
- 不将本评估期结果乘以 52 等系数冒充全年指标，也不将全部投资与短期运行费相加称为生命周期成本。

## 前后结果的可比性

比较口径A：同一口径下的预算/配置比较；时段、负荷与服务边界、运行排放口径及经济假设一致。

## 场景变更

前次运行：`93ecbb892f3f40ec94ab01a8e8c83136`；本次输入版本 2，计算状态见执行追溯。

```json
{
  "previous_version": 1,
  "current_version": 2,
  "previous_recommended": null,
  "current_recommended": "A",
  "previous_constraints": {
    "source_id": "demo-conditions",
    "budget_yuan": 60000.0,
    "grid_limit_kw": 12.0,
    "pv_limit_kw": 180.0,
    "emission_limit_kg": 230.0
  },
  "current_constraints": {
    "source_id": "revision-v2",
    "budget_yuan": 60000.0,
    "grid_limit_kw": 12.0,
    "pv_limit_kw": 180.0,
    "emission_limit_kg": 239.7412109375
  },
  "scenarios": [
    {
      "candidate_id": "A",
      "previous_status": "infeasible",
      "current_status": "optimal",
      "previous_valid": false,
      "current_valid": true,
      "delta_pv_kw": 0.0,
      "delta_battery_power_kw": 0.0,
      "delta_battery_energy_kwh": 0.0,
      "delta_hp_kw_th": 0.0,
      "delta_boiler_kw_th": 0.0
    },
    {
      "candidate_id": "C",
      "previous_status": "infeasible",
      "current_status": "infeasible",
      "previous_valid": false,
      "current_valid": false,
      "delta_pv_kw": 0.0,
      "delta_battery_power_kw": 0.0,
      "delta_battery_energy_kwh": 0.0,
      "delta_hp_kw_th": 0.0,
      "delta_boiler_kw_th": 0.0
    },
    {
      "candidate_id": "D",
      "previous_status": "rejected",
      "current_status": "rejected",
      "previous_valid": false,
      "current_valid": false,
      "delta_pv_kw": 0.0,
      "delta_battery_power_kw": 0.0,
      "delta_battery_energy_kwh": 0.0,
      "delta_hp_kw_th": 0.0,
      "delta_boiler_kw_th": 0.0
    }
  ],
  "comparison_basis": {
    "kind": "A_same_basis",
    "directly_comparable": true,
    "checks": [
      {
        "field": "period",
        "label": "评估时段、步长与完整年/快速模式",
        "group": "period",
        "same": true,
        "previous_sha256": "654f00c6f718dfad8b37ac2331c0573d096d667cb069b1d95497dcb1e54bb804",
        "current_sha256": "654f00c6f718dfad8b37ac2331c0573d096d667cb069b1d95497dcb1e54bb804"
      },
      {
        "field": "boundary",
        "label": "电热服务与计量边界",
        "group": "service",
        "same": true,
        "previous_sha256": "255f7db992bd7189f8316c129efca932b1607f3f84a233428b242da0bd774dd9",
        "current_sha256": "255f7db992bd7189f8316c129efca932b1607f3f84a233428b242da0bd774dd9"
      },
      {
        "field": "data.electric_load_kw",
        "label": "常规电负荷",
        "group": "service",
        "same": true,
        "previous_sha256": "9ce047dc14e9e2f529c2f6193480c00f34d03bb288b24e3e03ce2c4b3ba4d9eb",
        "current_sha256": "9ce047dc14e9e2f529c2f6193480c00f34d03bb288b24e3e03ce2c4b3ba4d9eb"
      },
      {
        "field": "data.heat_load_kw_th",
        "label": "供热负荷",
        "group": "service",
        "same": true,
        "previous_sha256": "8874726dfa6b3919ad7816bde42299c30b084b5aba6366a6414295f3f7f86450",
        "current_sha256": "8874726dfa6b3919ad7816bde42299c30b084b5aba6366a6414295f3f7f86450"
      },
      {
        "field": "emission_species",
        "label": "排放物质",
        "group": "emissions",
        "same": true,
        "previous_sha256": "0a30397b5d5fb089a50fd165471047327caf246c58ee9223fbe98bf928c5df6b",
        "current_sha256": "0a30397b5d5fb089a50fd165471047327caf246c58ee9223fbe98bf928c5df6b"
      },
      {
        "field": "emission_scope",
        "label": "运行排放范围与因子来源条件",
        "group": "emissions",
        "same": true,
        "previous_sha256": "2316054db540fd292a47c856d1f328557957d996cf80a17a183a9636ca1d99fa",
        "current_sha256": "2316054db540fd292a47c856d1f328557957d996cf80a17a183a9636ca1d99fa"
      },
      {
        "field": "data.grid_emission_factor",
        "label": "电网运行排放因子",
        "group": "emissions",
        "same": true,
        "previous_sha256": "67bd1f11afc7339c7b7c0c0684c5037be4ee7084dba758f1071de903c9497814",
        "current_sha256": "67bd1f11afc7339c7b7c0c0684c5037be4ee7084dba758f1071de903c9497814"
      },
      {
        "field": "data.gas_emission_factor",
        "label": "燃气运行排放因子",
        "group": "emissions",
        "same": true,
        "previous_sha256": "c9b50a3534efde1f6938d8028b52626d25ef96d785623935dbe80b68754e30a9",
        "current_sha256": "c9b50a3534efde1f6938d8028b52626d25ef96d785623935dbe80b68754e30a9"
      },
      {
        "field": "data.electricity_price",
        "label": "电价",
        "group": "economics",
        "same": true,
        "previous_sha256": "be0820a47bc903d2c7124248dc873a0e9561ddbe51916708d7ef8fcaf81c62b1",
        "current_sha256": "be0820a47bc903d2c7124248dc873a0e9561ddbe51916708d7ef8fcaf81c62b1"
      },
      {
        "field": "data.gas_price",
        "label": "燃气价格",
        "group": "economics",
        "same": true,
        "previous_sha256": "233af321acfd911550b498fabbaf7e6e951f55fa84e4c494b525f260c2dfbd7b",
        "current_sha256": "233af321acfd911550b498fabbaf7e6e951f55fa84e4c494b525f260c2dfbd7b"
      },
      {
        "field": "economics",
        "label": "规划年数、折现率、寿命、更换、残值及维护假设",
        "group": "economics",
        "same": true,
        "previous_sha256": "74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b",
        "current_sha256": "74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b"
      },
      {
        "field": "device_costs",
        "label": "设备单价、安装费与接入投资假设",
        "group": "economics",
        "same": true,
        "previous_sha256": "721c45c510ef8c395c503ff440610700740c15ca8022c181d6bca563f2a85222",
        "current_sha256": "721c45c510ef8c395c503ff440610700740c15ca8022c181d6bca563f2a85222"
      },
      {
        "field": "investment_scope",
        "label": "既有/新增投资边界",
        "group": "economics",
        "same": true,
        "previous_sha256": "c9eb10e24ffcbac15e8aa77a8a4bd0357321ab8d8e34a7a2da7439cfd078536e",
        "current_sha256": "c9eb10e24ffcbac15e8aa77a8a4bd0357321ab8d8e34a7a2da7439cfd078536e"
      },
      {
        "field": "device_physics",
        "label": "效率、COP与SOC物理假设",
        "group": "resource",
        "same": true,
        "previous_sha256": "1d9187228bf403456cd9af96e008a34d024c478c8e8f62d9a9cd908f00d31bd9",
        "current_sha256": "1d9187228bf403456cd9af96e008a34d024c478c8e8f62d9a9cd908f00d31bd9"
      },
      {
        "field": "data.pv_per_kw",
        "label": "同期光伏资源",
        "group": "resource",
        "same": true,
        "previous_sha256": "735bba29ded36e56f7c8c268f7e7cd980882c736b5410386984c09d71e1b8761",
        "current_sha256": "735bba29ded36e56f7c8c268f7e7cd980882c736b5410386984c09d71e1b8761"
      }
    ],
    "changed_labels": [],
    "summary": "比较口径A：同一口径下的预算/配置比较；时段、负荷与服务边界、运行排放口径及经济假设一致。",
    "note": "该判断核对已声明输入口径，不代表来源、工程假设或实测边界已获外部核实。原始差值为当前减基准；不同候选ID不强行配对。"
  },
  "note": "差值为当前运行减前次运行；比较口径A：同一口径下的预算/配置比较；时段、负荷与服务边界、运行排放口径及经济假设一致。"
}
```

## 执行追溯

状态流转：接收任务 → 校验输入 → 准备运行 → 生成候选 → 求解 → 结果校验 → 求解 → 结果校验 → 求解 → 结果校验 → 比较 → 报告 → 完成

| 工具 | 输入版本 | 状态 | 耗时 秒 | 结果文件 | 摘要 |
| --- | --- | --- | --- | --- | --- |
| validate_inputs | 2 | success | 0.0012 | outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/tools/001_validate_inputs.json | validate_inputs 已执行并通过输入/输出 schema 校验 |
| build_candidates | 2 | success | 0.0004618 | outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/tools/002_build_candidates.json | build_candidates 已执行并通过输入/输出 schema 校验 |
| solve_dispatch | 2 | success | 0.0035 | outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/tools/003_solve_dispatch.json | solve_dispatch 已执行并通过输入/输出 schema 校验 |
| validate_solution | 2 | success | 0.0009965 | outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/tools/004_validate_solution.json | validate_solution 已执行并通过输入/输出 schema 校验 |
| solve_dispatch | 2 | success | 0.0006715 | outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/tools/005_solve_dispatch.json | solve_dispatch 已执行并通过输入/输出 schema 校验 |
| validate_solution | 2 | success | 0.0004412 | outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/tools/006_validate_solution.json | validate_solution 已执行并通过输入/输出 schema 校验 |
| solve_dispatch | 2 | success | 0.0004313 | outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/tools/007_solve_dispatch.json | solve_dispatch 已执行并通过输入/输出 schema 校验 |
| validate_solution | 2 | success | 0.0004117 | outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/tools/008_validate_solution.json | validate_solution 已执行并通过输入/输出 schema 校验 |
| compare_scenarios | 2 | success | 0.0006425 | outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/tools/009_compare_scenarios.json | compare_scenarios 已执行并通过输入/输出 schema 校验 |
| generate_report | 2 | success | 0.0015 | outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/tools/010_generate_report.json | generate_report 已执行并通过输入/输出 schema 校验 |

结果文件：

- json: `outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/result.json`
- csv: `outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/scenarios.csv`
- markdown: `outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/report.md`
- dispatch_A: `outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/dispatch_A.csv`
- dispatch_C: `outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/dispatch_C.csv`
- dispatch_D: `outputs/decision_demo_validation/repair/070ec5e96171119f3b36efbc3834bf9bdcbd02d1d53a610f0f05dea32e44b341/search/1409a3da72e29ac8cf0b69497ad2d3d28aa566a4e1ee40fa21af4c25d2efb4de/runs/5f73cbba7a2845d38fb3a7a3093ca951/dispatch_D.csv`
